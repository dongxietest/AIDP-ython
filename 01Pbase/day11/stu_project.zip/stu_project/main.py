# file: main.py

from stu_info.controller  import run

run()