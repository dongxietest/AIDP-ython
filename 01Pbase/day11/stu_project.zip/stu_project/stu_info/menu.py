# file : stu_info/menu.py

# 此文件用来存放菜单
def show_menu():
    print("+---------------------------+")
    print("| 1) 添加学生信息             |")
    print("| 2) 显示所有学生信息          |")
    print("| 3) 删除学生信息             |")
    print("| 4) 修改学生成绩             |")
    print("| 5) 按学生成绩高-低显示学生信息 |")
    print("| 6) 按学生成绩低-高显示学生信息 |")
    print("| 7) 按学生年龄高-低显示学生信息 |")
    print("| 8) 按学生年龄低-高显示学生信息 |")
    print("| 9) 从文件中读取数据(si.txt)  |")
    print("| 10) 保存信息到文件(si.txt)  |")
    print("| 11) 保存到excel文件(infos.csv)  |")
    print("| 12) 从文件中读取excel文件(infos.csv) |")
    print("| q) 退出                    |")
    print("+---------------------------+")

