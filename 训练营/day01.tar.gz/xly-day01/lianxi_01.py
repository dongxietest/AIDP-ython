print("   *")
print("  ***")
print(" *****")
print("*******")

